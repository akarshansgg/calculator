//selection sort on user define array

// let selectionSort = [1, 2, 3, 4, 5, 6,];

// function selectionSort(array) {
//     for (let i = 0; i < array.length - 1; i++) {
  
//       let minIndex = i;
//       for (let j = i + 1; j < array.length; j++) {
//         if (array[j] < array[minIndex]) {
//           minIndex = j;
//         }     
//       }
//       [array[i], array[minIndex]] = [array[minIndex], array[i]];
//     }
//     return array;
// }




const str = prompt("Enter some value");
const pattern = prompt ("find length");

const index = bruteForce(str, pattern);

if (index !== -1) {
  console.log("Pattern found at String: " + index);
} else {
  console.log("Pattern not found in the string");
}

function bruteForce(str, pattern) {
  const n = str.length;
  const m = pattern.length;

  for (let i = 0; i <= n - m; i++) {
      let j;
      for (j = 0; j < m; j++) {
          if (str.charAt(i + j) !== pattern.charAt(j)) {
              break;
          }
      }

      if (j === m) {
          return i; 
      }
  }

  return -1;
}