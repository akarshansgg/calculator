// JavaScript

const header = document.querySelector('header');
const nav = document.querySelector('nav');
const navLinks = document.querySelectorAll('nav a');

// Toggle Mobile Navigation
const toggleMobileNav = () => {
  nav.classList.toggle('show-nav');
}

// Add Event Listener to Mobile Navigation Links
navLinks.forEach(link => {
  link.addEventListener('click', toggleMobileNav);
});